function zout= myFun(x)

    zout = -sin(x(1))^2*cos(x(2))*x(1);