function [ F ] = ttu_fun( R)
    global h
    F=pi*R*sqrt(R^2+h^2)-100;
   
end

