%%
% Graphical UI for dynamics simulations ME 3050  
% Tristan Hill 11/18/2015
% 
%%

clear all
close all
clc

% start the applet
myui_11_18_2015
